
import java.util.Scanner;
import java.util.Random;
import ed.linear.nseq.*;
public class ex4{
	public static void main(String[] args) {
		Random r=new Random();
		float a;
		Pilha pilha = new Pilha();
		for(int i=0;i<5;i++) {
			a=r.nextFloat()*100;
			pilha.adicionar(a);
			System.out.println(pilha.toString());
		}
		System.out.println("Pilha: "+pilha.toString());
		while(pilha.vazia()!=true) {
			pilha.remover();
			System.out.println("Pilha removendo a posi��o "+(pilha.comprimento()+1)+": "+pilha.toString());
		}
		System.out.println("Pilha: "+pilha.toString());
	}
}