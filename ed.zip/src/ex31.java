import java.util.Random;
import ed.linear.nseq.*;
public class ex31{
	public static void main(String[] args) {
		Random r=new Random();
		ListaLigada lista= new ListaLigada();
		int e,a;
		for(int i=0;i<10;i++) {
			e=r.nextInt(100);
			lista.adicionar(e);
			System.out.println(lista.toString());
		}
		for(int i=lista.comprimento()-1;i>=0;i--) {
			System.out.println("Lista: "+lista.toString());
			a=(int) lista.elemento(i);
			if(a%2==0){
				if(i==4) {
					lista.remover(i);
				}
				else {
				lista.remover(i);
				}
			}
		}
	}
}