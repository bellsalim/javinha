
import java.util.Scanner;

import ed.linear.nseq.*;

public class ex1{
	public static void main(String[] args) {
		Pilha pilha = new Pilha();
		int e;
		System.out.println(pilha.comprimento());
		Scanner sc=new Scanner(System.in);
		for(int i=0;i<10;i++) {
			System.out.println("Digite o n�mero inteiro:");
			e=sc.nextInt();
			pilha.adicionar(e);
			System.out.println("Pilha:"+pilha.toString());
		}
	}
}