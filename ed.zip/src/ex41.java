import java.util.Random;
import ed.linear.nseq.*;
public class ex41{
	public static void main(String[] args) {
		Random r=new Random();
		ListaLigada lista = new ListaLigada();
		float a;
		for(int i=0;i<5;i++) {
			a=r.nextFloat()*100;
			lista.adicionar(a);
			System.out.println(lista.toString());
		}
		int teste=lista.comprimento();
		for(int i=teste-1;i>=0;i--) {
			System.out.println("Lista removendo a posi��o "+lista.comprimento()+": "+lista.toString());
			lista.remover(i);
			}
		System.out.println("Lista:"+lista.toString()+" "+lista.comprimento());
		}
	}