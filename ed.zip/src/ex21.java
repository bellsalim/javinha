import java.util.Scanner;
import ed.linear.nseq.*;
public class ex21{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		boolean a=false;
		int i=0;
		Fila filasing = new Fila();
		Fila filaplur= new Fila();
		String e="";
		String fim="<fim>";
	    do {
	    	System.out.println("Digite:");
			e=sc.nextLine();
			a=e.equals(fim);
			if(a==true) {
			}
			else {if(e.charAt(e.length()-1)=='s'){
				filaplur.adicionar(e);
				System.out.println("Pilha plural: "+filaplur.toString());
			}else {
				filasing.adicionar(e);
				System.out.println("Pilha singular: "+filasing.toString());
			}
		}
	        i++;
	        System.out.println(i);
	      } while (i<20 && a!=true);
		System.out.println("Pilha plural: "+filaplur.toString()+", Comprimento:"+filaplur.comprimento());
		System.out.println("Pilha singular: "+filasing.toString()+", Comprimento:"+filasing.comprimento());
		
	}
}