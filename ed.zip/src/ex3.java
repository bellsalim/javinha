
import java.util.Random;
import ed.linear.nseq.*;
public class ex3{
	public static void main(String[] args) {
		Random r=new Random();
		Pilha pilhaux= new Pilha();
		Pilha pilha= new Pilha();
		int e,a;
		for(int i=0;i<5;i++) {
			e=r.nextInt(100);
			pilhaux.adicionar(e);
			System.out.println(pilhaux.toString());
		}
		for(int i=pilhaux.comprimento()-1;i>=0;i--) {
			a=(int) pilhaux.elemento(i);
			if(a%2!=0){
				pilha.adicionar(a);
				System.out.println("Pilha: "+pilha.toString());
				}
			pilhaux.remover();
			}
		}
	}