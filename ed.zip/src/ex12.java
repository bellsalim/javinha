import java.util.Random;

import ed.linear.nseq.*;

public class ex12{
	public static void main(String[] args) {
		Fila Fila = new Fila();
		int e;
		Random r=new Random();
		for(int i=0;i<10;i++) {
			e=r.nextInt(100);
			Fila.adicionar(e);
			System.out.println("Fila:"+Fila.toString());
		}
	}
}