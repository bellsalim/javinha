import java.util.Random;
import ed.linear.nseq.*;
public class ex32{
	public static void main(String[] args) {
		Random r=new Random();
		Fila fila= new Fila();
		Fila filaux= new Fila();
		int e,a,t;
		for(int i=0;i<10;i++) {
			e=r.nextInt(100);
			filaux.adicionar(e);
			System.out.println(filaux.toString());
		}
		System.out.println("Filaux: "+filaux.toString());
		int teste=filaux.comprimento();
		while(filaux.vazia()!=true) {
			t=0;
			a=(int) filaux.elemento(t);
			if(a%2!=0) {
				fila.adicionar(a);
				System.out.println("Fila: "+fila.toString());
			}
			filaux.remover();
			}
		System.out.println("Fila final: "+fila.toString());
		}
}