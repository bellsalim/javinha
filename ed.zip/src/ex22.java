
import java.util.Scanner;
import ed.linear.nseq.*;
public class ex22{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		Fila filasing = new Fila();
		Fila filaplur= new Fila();
		String e="";
		String fim="<fim>";
		boolean a=false;
		int i=0;
	    do {
	    	System.out.println("Digite:");
			e=sc.nextLine();
			a=e.equals(fim);
			if(a==true) {
			}
			else {if(e.charAt(e.length()-1)=='s'){
				filaplur.adicionar(e);
				System.out.println("Fila plural: "+filaplur.toString());
			}else {
				filasing.adicionar(e);
				System.out.println("Fila singular: "+filasing.toString());
			}
		}
	        i++;
	        System.out.println(i);
	      } while (i<20 && a!=true);
		System.out.println("Fila plural: "+filaplur.toString()+", Comprimento:"+filaplur.comprimento());
		System.out.println("Fila singular: "+filasing.toString()+", Comprimento:"+filasing.comprimento());
		
	}
}