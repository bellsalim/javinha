
import java.util.Scanner;
import ed.linear.nseq.*;
public class ex2{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		Pilha pilhasing = new Pilha();
		Pilha pilhaplur= new Pilha();
		String e="";
		String fim="<fim>";
		boolean a=false;
		int i=0;
	    do {
	    	System.out.println("Digite:");
			e=sc.nextLine();
			a=e.equals(fim);
			if(a==true) {
			}
			else {if(e.charAt(e.length()-1)=='s'){
				pilhaplur.adicionar(e);
				System.out.println("Pilha plural: "+pilhaplur.toString());
			}else {
				pilhasing.adicionar(e);
				System.out.println("Pilha singular: "+pilhasing.toString());
			}
		}
	        i++;
	        System.out.println(i);
	      } while (i<20 && a!=true);
		System.out.println("Pilha plural: "+pilhaplur.toString()+", Comprimento:"+pilhaplur.comprimento());
		System.out.println("Pilha singular: "+pilhasing.toString()+", Comprimento:"+pilhasing.comprimento());
		
	}
}