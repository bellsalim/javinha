import java.util.Random;
import ed.linear.nseq.*;
public class ex42{
	public static void main(String[] args) {
		Random r=new Random();
		int b=0;
		Fila fila = new Fila();
		float a;
		for(int i=0;i<5;i++) {
			a=r.nextFloat()*100;
			fila.adicionar(a);
			System.out.println(fila.toString());
		}
		System.out.println("fila: "+fila.toString()+", Comprimento: "+fila.comprimento());
		while(fila.vazia()!=true) {
			b++;
			fila.remover();
			System.out.println("fila p�s remo��o da posi��o "+b+": "+fila.toString());
		}
		System.out.println("fila: "+fila.toString());
	}
}